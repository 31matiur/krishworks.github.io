<?php
function myfun($text) {
	echo "<p>Hi! A very good $text to you</p>";
} 
myfun('morning');
myfun('afternoon');
myfun('night');
?>

<h2>Our website name is <?php bloginfo('name'); ?></h2>