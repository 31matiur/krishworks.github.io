<?php
   /**
    * Template Name: Search Page
    */
   get_header();
   while ( have_posts() ) : the_post();
   ?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-wEmeIV1mKuiNpC+IOBjI7aAzPcEZeedi5yW5f2yOq55WWLwNGmvvx4Um1vskeMj0" crossorigin="anonymous">

    <title>Student Details</title>
  </head>
  <body>
   <div class="container">
  <div class="row">
<!-- Start of Form -->
<form action="" method="POST">
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Search Here</label>
    <input type="text" class="form-control" name="search">
  </div>
  
  <button type="submit" name="submit" class="btn btn-primary">Submit</button>
</form>

<!-- End of Form -->

<!-- Start of second form -->

<form action="" method="POST">
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Enter marks to get students information</label>
    <input type="text" class="form-control" name="search_x">
  </div>
  
  <button type="submit" name="submit_x" class="btn btn-primary">Submit</button>
</form>

<!-- End of seond form -->

<?php
/* Condition to check when the first search button is clicked */
if(isset($_REQUEST['submit']))
{
global $wpdb; /*Taken a global variable*/
$search = $_REQUEST['search']; /* Mapping the value taken from user */
/* Query for searching by student name or phone number and storing output to result variable */
$result = $wpdb->get_results("SELECT * FROM wp_students WHERE phone_number = '$search' OR  student_name = '$search'");
$wpdb->get_results( "SELECT COUNT(*) FROM  wp_students WHERE phone_number = '$search' "); /* Counting number of rows */


if($wpdb->num_rows > 0)
{
    ?>
    <table class="table">
      <thead>
        <tr>
          <th scope="col">id</th>
          <th scope="col">Student Name</th>
          <th scope="col">Phone Number</th>
          <th scope="col">Email Id </th>
          <th scope="col">Marks Subject1</th>
          <th scope="col">Marks Subject2</th>
          <th scope="col">Marks Subject3</th>
          <th scope="col">Marks Subject4</th>
          <th scope="col">Marks Subject5</th>
          <th scope="col">Total Marks</th>
        </tr>
      </thead>
      <tbody>
        <?php
        foreach ($result as $student) {
            ?>
            <tr>
          <td><?php echo $student->id; ?></td>
          <td><?php echo $student->student_name; ?></td>
          <td><?php echo $student->phone_number; ?></td>
          <td><?php echo $student->email_id; ?></td>
          <td><?php echo $student->marks_subject1; ?></td>
          <td><?php echo $student->marks_subject2; ?></td>
          <td><?php echo $student->marks_subject3; ?></td>
          <td><?php echo $student->marks_subject4; ?></td>
          <td><?php echo $student->marks_subject5; ?></td>
          <td><?php echo $student->total_marks; ?></td>
        </tr>
            <?php
        }
        ?>
      </tbody>
    </table>
        <?php
}
}
?>
<!-- Start of second condition -->
<?php
/* Condition to check when the first search button is clicked */
if(isset($_REQUEST['submit_x']))
{
global $wpdb; /*Taken a global variable*/
$search = $_REQUEST['search_x']; /* Mapping the value taken from user */
/* Query for searching by student name or phone number and storing output to result variable */
$result = $wpdb->get_results("SELECT * FROM wp_students WHERE total_marks >= '$search'");


    ?>
    <table class="table">
      <thead>
        <tr>
          <th scope="col">id</th>
          <th scope="col">Student Name</th>
          <th scope="col">Phone Number</th>
          <th scope="col">Email Id </th>
          <th scope="col">Marks Subject1</th>
          <th scope="col">Marks Subject2</th>
          <th scope="col">Marks Subject3</th>
          <th scope="col">Marks Subject4</th>
          <th scope="col">Marks Subject5</th>
          <th scope="col">Total Marks</th>
        </tr>
      </thead>
      <tbody>
        <?php
        foreach ($result as $student) {
            ?>
            <tr>
          <td><?php echo $student->id; ?></td>
          <td><?php echo $student->student_name; ?></td>
          <td><?php echo $student->phone_number; ?></td>
          <td><?php echo $student->email_id; ?></td>
          <td><?php echo $student->marks_subject1; ?></td>
          <td><?php echo $student->marks_subject2; ?></td>
          <td><?php echo $student->marks_subject3; ?></td>
          <td><?php echo $student->marks_subject4; ?></td>
          <td><?php echo $student->marks_subject5; ?></td>
          <td><?php echo $student->total_marks; ?></td>
        </tr>
            <?php
        }
        ?>
      </tbody>
    </table>
        <?php

}
?>
<!-- End of second condition -->
</div>
</div>
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-p34f1UUtsS3wqzfto5wAAmdvj+osOnFyQFpp4Ua3gs/ZVWx6oOypYoCJhGGScy+8" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.min.js" integrity="sha384-lpyLfhYuitXl2zRZ5Bn2fqnhNAKOAaM/0Kr9laMspuaMiZfGmfwRNFh8HlMy49eQ" crossorigin="anonymous"></script>
    -->
  </body>
</html>

  <?php endwhile; ?>         
<!-- <?php get_footer(); ?> -->